# AI Trading City — Free starter

This is a **simulation-only** starter. It does not connect to a broker, use API credentials, submit orders, or use real market data. Its city uses synthetic stock movements.

## Run on a computer

1. Install Python 3 if needed.
2. Unzip this folder.
3. Open a terminal in the unzipped folder.
4. Run `python -m http.server 8000` (Windows may use `py -m http.server 8000`).
5. Open `http://localhost:8000` on that computer.

The 3D renderer loads Three.js from a public CDN, so an internet connection is needed for the visuals.

## Next steps

1. Create your own free Alpaca paper account and GitHub account, then keep their credentials private.
2. Backtest the strategy on historical candles.
3. Add a Python backend, robust risk management, data logging, and paper brokerage connection.
4. Only later consider remote access with authentication and secure hosting.

**Never commit API secrets to a repository.** This demo is not a trading strategy or a profitable trading bot.
